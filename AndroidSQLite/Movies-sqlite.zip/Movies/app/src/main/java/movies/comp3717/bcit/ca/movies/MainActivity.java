package movies.comp3717.bcit.ca.movies;

import android.app.ListActivity;
import android.content.ContentValues;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import movies.comp3717.bcit.ca.movies.DataContract.DataEntry;

public class MainActivity extends ListActivity
{
    private BaseAdapter titlesAdapater;
    private DataDbHelper dataDBHelper;

    @Override
    protected void onCreate(final Bundle savedInstanceState)
    {
        final Resources      res;
        final String[]       titles;
        final SQLiteDatabase db;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dataDBHelper   = new DataDbHelper(this);
        res            = getResources();
        db             = dataDBHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        titles         = res.getStringArray(R.array.movie_titles);

        for(final String title : titles)
        {
            long newRowId;

            Log.d("title", title);
            values.put(DataEntry.COLUMN_NAME_VALUE, title + "!");
            newRowId = db.insert(
                    DataEntry.TABLE_NAME,
                    null,
                    values);
        }


//        titlesAdapater = new ArrayAdapter<String>(this,
//                android.R.layout.simple_list_item_1,
//                titles);

        titlesAdapater = new SimpleCursorAdapter(this,
                                                 android.R.layout.simple_list_item_1,
                                                 getAllTitles(db),
                                                 new String[] { DataEntry.COLUMN_NAME_VALUE },
                                                 new int[] { android.R.id.text1 });
        setListAdapter(titlesAdapater);
    }

    @Override
    public void onListItemClick(final ListView list,
                                final View     view,
                                final int      position,
                                final long     id)
    {
        final String title;

//        title = titlesAdapater.getItem(position);
        Toast.makeText(this, Integer.toString(position), Toast.LENGTH_SHORT).show();
    }

    public Cursor getAllTitles(final SQLiteDatabase db)
    {
        Cursor cursor;

        cursor = db.query(DataEntry.TABLE_NAME,
                          new String[]
                          {
                              DataEntry._ID,
                              DataEntry.COLUMN_NAME_VALUE
                          },
                          null,
                          null,
                          null,
                          null,
                          null);

        Log.d("X", Integer.toString(cursor.getCount()));

        return cursor;
    }
}
